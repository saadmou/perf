#!/bin/sh

HOST=$(uname -n|awk -F"." '{print $1}') 
kill $(ps -ef |egrep "A30.sh|nmon.$HOST" |grep -v grep |awk '{print $2}')

