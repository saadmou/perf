#!/bin/sh

#Maximum de boucles
MAX=8

#Periode
#TIME=1800
TIME=300

i=0
while [ "$i" -lt "$MAX" ]
do
./Nmon.v8.sh $TIME
 i=$(expr $i + 1 )
done

