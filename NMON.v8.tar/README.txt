Adapter la periode et le nombre de fichier dans a30.sh
Installer ksh "yum install ksh"

