#! /bin/sh
# Historique:
# 30 Mai 2018: Ajout -T pour avoir les details des commandes dans  l'onglet UARG

#sed -i -e 's/\r$//' Nmon.v4.sh

HOST=$(uname -n|awk -F"." '{print $1}')
DATE=$(date +%d"."%m"."%y"-"%Hh"."%Mmn)
fic=nmon.$HOST.$DATE.nmon

# Prise de mesure par default toute les 1 seconde. Prise de 1200 echantillons (20 minutes)
# Le script peut etre appele avec le nombre de prise toutes les X secondes  et un nombre d'echantillons donne
# Nmon.sh 300 -> une prise toute les 1 secondes, prise de 300 echantillons (duree total = 1 x 300 = 300 secondes)
# Nmon.sh 4 300 -> une prise de mesure toutes les 4 secondes, prise de 300 echantillons (Duree total: 4 x 300 = 1200 secondes)

Usage ()
{
      #clear 
      echo "Usage: $0 [X] [N]"
      echo "X: intervale entre 2 napshots"
      echo "N: nombre de snapshots"
      echo "La duree du monitoring sera egale a X mulitiplie par  N"
      exit 
}

kill_old_nmon ()
{
#Stop all old nmon process
liste_proc=$(ps -ef |grep "./nmon -F" |grep -v grep |awk '{print $2}')
for p in $liste_proc
do 
   echo "kill $p"
   kill $p
done
}

case $# in 
1) INTERVAL=1 ; NBR_SNAPS=$1 
case $1 in
   h|-h|H|-H|help|HELP)
   Usage
  ;;
  *)
	if [ "$(echo $1 | grep [[:digit:]+])" = "" ]
	then
   	  Usage
	fi
   ;;
  esac
;;
2) INTERVAL=$1 ; NBR_SNAPS=$2 ;;
*) INTERVAL=1; NBR_SNAPS=1200 ;;
esac

echo "Kill des anciens nmon"
kill_old_nmon

if [ -x "/usr/bin/nmon" ]
then
 REP_BIN="/usr/bin"
else
 REP_BIN="."
fi

echo "$REP_BIN/nmon -F $fic -s$INTERVAL -c$NBR_SNAPS -T -I 0.001 -N"
echo "Prise de $NBR_SNAPS mesures par intervale de $INTERVAL secondes"
$REP_BIN/nmon -F $fic -s$INTERVAL -c$NBR_SNAPS -T  -I 0.001 -N

/bin/chmod 644 $fic
echo "resultat brut: $fic"

SleepNBR_SNAPS=$(($NBR_SNAPS * $INTERVAL))

#Utile pour nmonchart et l'appel du script par une boucle externe
sleep $SleepNBR_SNAPS
#sleep 2

#echo "./nmonchart $fic $fic.html"
# ./nmonchart $fic $fic.html
#echo "resultat html: $fic.html"

