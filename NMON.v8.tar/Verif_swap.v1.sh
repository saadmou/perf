#!/bin/bash
# Get current swap usage for all running processes
# Erik Ljungstrom 27/05/2011
# Modified by Mikko Rantalainen 2012-08-09
# Pipe the output to "sort -nk3" to get sorted output
# Modified by Marc Methot 2014-09-18
# removed the need for sudo
# add results in a csv file 2017-09-13 (SM)
# add process swapped the end of csv file 2018-06-01 (SM)

#sed -i -e 's/\r$//' Verif_swap.v1.sh

HOST=$(uname -n)
DATE=$(date +%d"/"%m"/"%y":"%H":"%M":"%S)
HEADER="HOST;DATE;PID;SUM (KB);PROGNAME"
echo $HEADER > swap_usage_$HOST.csv


SUM=0
OVERALL=0

echo "Verification du swap en cours...."

for DIR in `find /proc/ -maxdepth 1 -type d -regex "^/proc/[0-9]+"`
do
    PID=`echo $DIR | cut -d / -f 3`
    PROGNAME=`ps -p $PID -o comm --no-headers`
    for SWAP in `grep VmSwap $DIR/status 2>/dev/null | awk '{ print $2 }'`
    do
        let SUM=$SUM+$SWAP
    done
    if (( $SUM > 0 )); then
        echo "PID=$PID swapped $SUM KB ($PROGNAME)"
        echo "$HOST;$DATE;PID=$PID;$SUM;$PROGNAME" >> swap_usage_$HOST.csv
    fi
    let OVERALL=$OVERALL+$SUM
    SUM=0
done
echo "Overall swap used: $OVERALL KB"

echo "Recuperation des process ...."

for PID in $(cat swap_usage_$HOST.csv |grep -v "$HEADER"|awk -F";" '{print $3}' |cut -d"=" -f2)
do
if [ ! -z "$PID" ]
then
    echo " -----------$PID ------" >> swap_usage_$HOST.csv
    #ps -ef |grep -w $PID >> swap_usage_$HOST.csv
    ps -p $PID >> swap_usage_$HOST.csv
fi
done
